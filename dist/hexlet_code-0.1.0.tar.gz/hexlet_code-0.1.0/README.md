### Hexlet tests and linter status:
[![Actions Status](https://github.com/romachelli/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/romachelli/python-project-49/actions)

   Header:

   My first project with 5 brain games.

   Package installation:
   1. make build
   2. make package-install
   3. make publish

      1. Brain-even:
<a href="https://asciinema.org/a/2Gnyyj0n3U9lx9V6Pr5ZbMZVH" target="_blank"><img src="https://asciinema.org/a/2Gnyyj0n3U9lx9V6Pr5ZbMZVH.svg" /></a>

      2. Brain-calc:
<a href="https://asciinema.org/a/ESu2i6uiMm6ONA7oQecYAAa4f" target="_blank"><img src="https://asciinema.org/a/ESu2i6uiMm6ONA7oQecYAAa4f.svg" /></a>

# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Project with 5 console games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/romachelli/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/romachelli/python-project-49/actions)\n\n                   Header:\n\n                   My first project with 5 brain games.\n\n                   Package installation:\n\n                   1.make install\n\n                   2.make build\n\n                   3.make package-install\n\n\n                  1.Brain-even:\n<a href="https://asciinema.org/a/2Gnyyj0n3U9lx9V6Pr5ZbMZVH" target="_blank"><img src="https://asciinema.org/a/2Gnyyj0n3U9lx9V6Pr5ZbMZVH.svg" /></a>\n\n\n                  2.Brain-calc:\n<a href="https://asciinema.org/a/ESu2i6uiMm6ONA7oQecYAAa4f" target="_blank"><img src="https://asciinema.org/a/ESu2i6uiMm6ONA7oQecYAAa4f.svg" /></a>\n\n\n                  3.Brain-gcd:\n<a href="https://asciinema.org/a/KKJ13V1YJpEdNDQyGRC5rA9GX" target="_blank"><img src="https://asciinema.org/a/KKJ13V1YJpEdNDQyGRC5rA9GX.svg" /></a>\n\n\n                  4.Brain-progression:\n<a href="https://asciinema.org/a/0QjzHwBcEdPqQZejagyEm6S8D" target="_blank"><img src="https://asciinema.org/a/0QjzHwBcEdPqQZejagyEm6S8D.svg" /></a>\n\n\n                  5.Brain-prime:\n<a href="https://asciinema.org/a/uo4VvcBnwUhrzEVSiGEVfc2Rk" target="_blank"><img src="https://asciinema.org/a/uo4VvcBnwUhrzEVSiGEVfc2Rk.svg" /></a>\n',
    'author': 'romachelli',
    'author_email': 'romakarabas63@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10.6,<4.0.0',
}


setup(**setup_kwargs)
